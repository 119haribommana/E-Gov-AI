/*
SQLyog Community v8.71 
MySQL - 5.5.30 : Database - ecitizen_db
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;




-- root
-- komali@211219

/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`ecitizen_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ecitizen_db`;

/*Table structure for table `ammavadi` */

DROP TABLE IF EXISTS `ammavadi`;

CREATE TABLE `ammavadi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `parent_name` varchar(255) NOT NULL,
  `caste` varchar(50) NOT NULL,
  `disabled` enum('Yes','No') NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `principal_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `aadhar_card` varchar(16) NOT NULL,
  `ration_card` varchar(20) NOT NULL,
  `bank_account` varchar(20) NOT NULL,
  `ifsc_code` varchar(11) NOT NULL,
  `district` varchar(100) NOT NULL,
  `mandal` varchar(100) NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aadhar_card` (`aadhar_card`),
  UNIQUE KEY `ration_card` (`ration_card`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `ammavadi` */

insert  into `ammavadi`(`id`,`student_name`,`age`,`parent_name`,`caste`,`disabled`,`school_name`,`principal_name`,`address`,`contact_number`,`aadhar_card`,`ration_card`,`bank_account`,`ifsc_code`,`district`,`mandal`,`submitted_at`) values (1,'satish',27,'r.yadaiah','SC','Yes','sri sai ram high school','chari','narsing','9912590974','616301037202','WPK123456','061010003124','50075','RR','Gandipet','2025-03-27 12:05:11'),(3,'sonu',24,'anab','ST','Yes','ajhdkjsajf','dsrh','hyd','6363636363','12311232112','wpk1234566','012303210235','50074','RR','Gandipet','2025-03-27 12:34:15'),(4,'app',25,'dhgdzfh','ST','Yes','gfchgfgfh','vhjhvh','ads','333333333','87878888','wpk8989889','213526352252','745285','qw','h','2025-03-27 13:13:33'),(5,'ramu',32,'uyuy','General','Yes','happy schlor','rangaya','narsing','12345674890','3.63653653','wpk1245875','01239874563','500014','RR','Gandipet','2025-03-27 16:51:19'),(6,'uma',29,'manjula','SC','No','zphs','govindaya','kokapet','8989898989','96968596','wpk968659','43125431256','500081','RR','lingampali','2025-03-27 17:26:03');

/*Table structure for table `contact_messages` */

DROP TABLE IF EXISTS `contact_messages`;

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `contact_messages` */

insert  into `contact_messages`(`id`,`name`,`email`,`message`,`created_at`) values (2,'Satish Kumar','rameshwaramsatishkumar@gmail.com','egwt','2025-03-27 13:53:44');

/*Table structure for table `policy_reviews` */

DROP TABLE IF EXISTS `policy_reviews`;

CREATE TABLE `policy_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `policy` text NOT NULL,
  `review` text NOT NULL,
  `sentiment` varchar(10) DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `policy_reviews` */

insert  into `policy_reviews`(`id`,`policy`,`review`,`sentiment`) values (2,'Amma Vodi Scheme','A great initiative that reduced school dropouts in our village!','Good'),(3,'Amma Vodi Scheme','amma vadi scheme is good to introtused the government and great schem of this policy\r\n','Good'),(4,'Amma Vodi Scheme','A great initiative that reduced school dropouts in our village!','Good'),(5,'Amma Vodi Scheme','It is a good policy for the housewives','Good'),(6,'Amma Vodi Scheme','Amma Vodi is a blessing for poor families struggling with school expenses','Bad'),(7,'Amma Vodi Scheme','The funds are not being credited on time, making it hard to rely on this scheme.','Average'),(8,'Rythu Bharosa','this is the best for framers thank you for supporting government','Good'),(9,'Rythu Bharosa','it is a good policy for the farmers','Good'),(10,'Rythu Bharosa','this policy is use full for framers ','Average');

/*Table structure for table `rythu_bandhu` */

DROP TABLE IF EXISTS `rythu_bandhu`;

CREATE TABLE `rythu_bandhu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `farmer_name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `aadhar_card` varchar(20) NOT NULL,
  `land_certificate` varchar(255) NOT NULL,
  `pan_card` varchar(20) NOT NULL,
  `landtype` enum('agriculture','commercial') NOT NULL,
  `landarea` varchar(100) NOT NULL,
  `district` varchar(255) NOT NULL,
  `mandal` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aadhar_card` (`aadhar_card`),
  UNIQUE KEY `pan_card` (`pan_card`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `rythu_bandhu` */

insert  into `rythu_bandhu`(`id`,`farmer_name`,`age`,`aadhar_card`,`land_certificate`,`pan_card`,`landtype`,`landarea`,`district`,`mandal`) values (1,'ryadaiah',56,'69696901234','ryadaiah','CPA564SD','agriculture','12','RR','Gandipet'),(2,'jhujjj',36,'69690123365','adcd','cou786j','commercial','3','RR','lingampali'),(3,'satish',27,'636013032546','ryadaiah','cgpk567h','commercial','4','RR','GANDIPET');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surname` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id`,`surname`,`name`,`lastname`,`dob`,`age`,`password`) values (1,'rameshwaram','Satish','Kumar','2024-10-12',0,'pbkdf2:sha256:260000$MmVMEsvo$3273c5373f5ba53add244293cd05086c5aa1eb9ee62ea7724a44e36e42b8b0ae'),(2,'ambc','sonu','reddy','2004-03-03',21,'pbkdf2:sha256:260000$vfT572Xo$2b0cd1786a0dbbc9dc1630cdeef699f40bbd9a69f02a08379c68e42d9f09df6d'),(3,'amur','sanju','kumar','1997-10-08',27,'12345'),(4,'kanchala','sorry','life','2018-02-01',7,'abcd1234'),(5,'kodicharla','uma','rani','1996-02-15',29,'umarani');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
